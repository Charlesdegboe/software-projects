﻿// Lab 3
// CIS 199-50
// Due: 9/24/2023
// Grading ID: A1010

// This program prompts the user for the radius of a sphere
// and then calculates its diameter, surface area, and 
// volume, Uses a PictureBox control.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        



        private void outputDiameter_TextChanged(object sender, EventArgs e) 

        {
           

        }

        private void calcButton_Click(object sender, EventArgs e)


        {
            double radius = Convert.ToDouble(outputRadius.Text);
            double diameter = 2 * radius;
            double surfaceArea = 4 * Math.PI * Math.Pow(radius, 2);
            double Volume = 4 * Math.PI * Math.Pow(radius, 3) / 3;
            // These are the lines that are going to be calculated

            outputDiameter.Text = $"{diameter:F2}";
            outputArea.Text = $"{surfaceArea:F2}";
            outputVolume.Text = $"{Volume:F2}";
        }
    }
}

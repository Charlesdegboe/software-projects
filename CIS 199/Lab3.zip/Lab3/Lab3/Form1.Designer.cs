﻿namespace Lab3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.topLeftPictureBox = new System.Windows.Forms.PictureBox();
            this.radPromptLbl = new System.Windows.Forms.Label();
            this.outputRadius = new System.Windows.Forms.TextBox();
            this.diameterLabel = new System.Windows.Forms.Label();
            this.outputDiameter = new System.Windows.Forms.TextBox();
            this.surfaceLabel = new System.Windows.Forms.Label();
            this.outputArea = new System.Windows.Forms.TextBox();
            this.volumeLabel = new System.Windows.Forms.Label();
            this.outputVolume = new System.Windows.Forms.TextBox();
            this.bottomRightPicture = new System.Windows.Forms.PictureBox();
            this.calcButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.topLeftPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bottomRightPicture)).BeginInit();
            this.SuspendLayout();
            // 
            // topLeftPictureBox
            // 
            this.topLeftPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("topLeftPictureBox.Image")));
            this.topLeftPictureBox.Location = new System.Drawing.Point(30, 12);
            this.topLeftPictureBox.Name = "topLeftPictureBox";
            this.topLeftPictureBox.Size = new System.Drawing.Size(315, 259);
            this.topLeftPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.topLeftPictureBox.TabIndex = 0;
            this.topLeftPictureBox.TabStop = false;
            // 
            // radPromptLbl
            // 
            this.radPromptLbl.AutoSize = true;
            this.radPromptLbl.Location = new System.Drawing.Point(336, 56);
            this.radPromptLbl.Name = "radPromptLbl";
            this.radPromptLbl.Size = new System.Drawing.Size(236, 32);
            this.radPromptLbl.TabIndex = 1;
            this.radPromptLbl.Text = "Radius of sphere:";
            // 
            // outputRadius
            // 
            this.outputRadius.Location = new System.Drawing.Point(585, 56);
            this.outputRadius.Name = "outputRadius";
            this.outputRadius.Size = new System.Drawing.Size(252, 38);
            this.outputRadius.TabIndex = 2;
            // 
            // diameterLabel
            // 
            this.diameterLabel.AutoSize = true;
            this.diameterLabel.Location = new System.Drawing.Point(89, 334);
            this.diameterLabel.Name = "diameterLabel";
            this.diameterLabel.Size = new System.Drawing.Size(129, 32);
            this.diameterLabel.TabIndex = 3;
            this.diameterLabel.Text = "Diameter";
            // 
            // outputDiameter
            // 
            this.outputDiameter.Location = new System.Drawing.Point(282, 331);
            this.outputDiameter.Name = "outputDiameter";
            this.outputDiameter.Size = new System.Drawing.Size(219, 38);
            this.outputDiameter.TabIndex = 4;
            this.outputDiameter.TextChanged += new System.EventHandler(this.outputDiameter_TextChanged);
            // 
            // surfaceLabel
            // 
            this.surfaceLabel.AutoSize = true;
            this.surfaceLabel.Location = new System.Drawing.Point(89, 433);
            this.surfaceLabel.Name = "surfaceLabel";
            this.surfaceLabel.Size = new System.Drawing.Size(179, 32);
            this.surfaceLabel.TabIndex = 5;
            this.surfaceLabel.Text = "Surface Area";
            // 
            // outputArea
            // 
            this.outputArea.Location = new System.Drawing.Point(282, 433);
            this.outputArea.Name = "outputArea";
            this.outputArea.Size = new System.Drawing.Size(219, 38);
            this.outputArea.TabIndex = 6;
            // 
            // volumeLabel
            // 
            this.volumeLabel.AutoSize = true;
            this.volumeLabel.Location = new System.Drawing.Point(89, 540);
            this.volumeLabel.Name = "volumeLabel";
            this.volumeLabel.Size = new System.Drawing.Size(111, 32);
            this.volumeLabel.TabIndex = 7;
            this.volumeLabel.Text = "Volume";
            // 
            // outputVolume
            // 
            this.outputVolume.Location = new System.Drawing.Point(282, 540);
            this.outputVolume.Name = "outputVolume";
            this.outputVolume.Size = new System.Drawing.Size(219, 38);
            this.outputVolume.TabIndex = 8;
            // 
            // bottomRightPicture
            // 
            this.bottomRightPicture.Image = ((System.Drawing.Image)(resources.GetObject("bottomRightPicture.Image")));
            this.bottomRightPicture.Location = new System.Drawing.Point(620, 458);
            this.bottomRightPicture.Name = "bottomRightPicture";
            this.bottomRightPicture.Size = new System.Drawing.Size(315, 259);
            this.bottomRightPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bottomRightPicture.TabIndex = 9;
            this.bottomRightPicture.TabStop = false;
            // 
            // calcButton
            // 
            this.calcButton.BackColor = System.Drawing.SystemColors.ControlLight;
            this.calcButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.calcButton.Location = new System.Drawing.Point(639, 136);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(159, 51);
            this.calcButton.TabIndex = 10;
            this.calcButton.Text = "Calculate";
            this.calcButton.UseVisualStyleBackColor = false;
            this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.calcButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(986, 746);
            this.Controls.Add(this.calcButton);
            this.Controls.Add(this.bottomRightPicture);
            this.Controls.Add(this.outputVolume);
            this.Controls.Add(this.volumeLabel);
            this.Controls.Add(this.outputArea);
            this.Controls.Add(this.surfaceLabel);
            this.Controls.Add(this.outputDiameter);
            this.Controls.Add(this.diameterLabel);
            this.Controls.Add(this.outputRadius);
            this.Controls.Add(this.radPromptLbl);
            this.Controls.Add(this.topLeftPictureBox);
            this.Name = "Form1";
            this.Text = "Lab 3";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.topLeftPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bottomRightPicture)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox topLeftPictureBox;
        private System.Windows.Forms.Label radPromptLbl;
        private System.Windows.Forms.TextBox outputRadius;
        private System.Windows.Forms.Label diameterLabel;
        private System.Windows.Forms.TextBox outputDiameter;
        private System.Windows.Forms.Label surfaceLabel;
        private System.Windows.Forms.TextBox outputArea;
        private System.Windows.Forms.Label volumeLabel;
        private System.Windows.Forms.TextBox outputVolume;
        private System.Windows.Forms.PictureBox bottomRightPicture;
        private System.Windows.Forms.Button calcButton;
    }
}


﻿namespace Lab_4
{
    partial class labFour
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gpaLabel = new System.Windows.Forms.Label();
            this.testScore = new System.Windows.Forms.Label();
            this.GPATextBox = new System.Windows.Forms.TextBox();
            this.TestScoreTextBox = new System.Windows.Forms.TextBox();
            this.ResultLabel = new System.Windows.Forms.Label();
            this.CalculateButton = new System.Windows.Forms.Button();
            this.AcceptedLabel = new System.Windows.Forms.Label();
            this.RejectedLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // gpaLabel
            // 
            this.gpaLabel.AutoSize = true;
            this.gpaLabel.Location = new System.Drawing.Point(47, 63);
            this.gpaLabel.Name = "gpaLabel";
            this.gpaLabel.Size = new System.Drawing.Size(350, 32);
            this.gpaLabel.TabIndex = 0;
            this.gpaLabel.Text = "Enter grade point average:";
            // 
            // testScore
            // 
            this.testScore.AutoSize = true;
            this.testScore.Location = new System.Drawing.Point(53, 190);
            this.testScore.Name = "testScore";
            this.testScore.Size = new System.Drawing.Size(355, 32);
            this.testScore.TabIndex = 1;
            this.testScore.Text = "Enter admission test score:";
            // 
            // GPATextBox
            // 
            this.GPATextBox.Location = new System.Drawing.Point(451, 56);
            this.GPATextBox.Name = "GPATextBox";
            this.GPATextBox.Size = new System.Drawing.Size(113, 38);
            this.GPATextBox.TabIndex = 2;
            // 
            // TestScoreTextBox
            // 
            this.TestScoreTextBox.Location = new System.Drawing.Point(451, 199);
            this.TestScoreTextBox.Name = "TestScoreTextBox";
            this.TestScoreTextBox.Size = new System.Drawing.Size(113, 38);
            this.TestScoreTextBox.TabIndex = 3;
            // 
            // ResultLabel
            // 
            this.ResultLabel.AutoSize = true;
            this.ResultLabel.Location = new System.Drawing.Point(138, 280);
            this.ResultLabel.Name = "ResultLabel";
            this.ResultLabel.Size = new System.Drawing.Size(271, 32);
            this.ResultLabel.TabIndex = 4;
            this.ResultLabel.Text = "Admission Decision:";
            // 
            // CalculateButton
            // 
            this.CalculateButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.CalculateButton.Location = new System.Drawing.Point(389, 368);
            this.CalculateButton.Name = "CalculateButton";
            this.CalculateButton.Size = new System.Drawing.Size(121, 51);
            this.CalculateButton.TabIndex = 5;
            this.CalculateButton.Text = "Admit?";
            this.CalculateButton.UseVisualStyleBackColor = false;
            this.CalculateButton.Click += new System.EventHandler(this.CalculateButton_Click);
            // 
            // AcceptedLabel
            // 
            this.AcceptedLabel.AutoSize = true;
            this.AcceptedLabel.Location = new System.Drawing.Point(13, 460);
            this.AcceptedLabel.Name = "AcceptedLabel";
            this.AcceptedLabel.Size = new System.Drawing.Size(141, 32);
            this.AcceptedLabel.TabIndex = 6;
            this.AcceptedLabel.Text = "Accepted:";
            // 
            // RejectedLabel
            // 
            this.RejectedLabel.AutoSize = true;
            this.RejectedLabel.Location = new System.Drawing.Point(19, 516);
            this.RejectedLabel.Name = "RejectedLabel";
            this.RejectedLabel.Size = new System.Drawing.Size(135, 32);
            this.RejectedLabel.TabIndex = 7;
            this.RejectedLabel.Text = "Rejected:";
            // 
            // labFour
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(932, 649);
            this.Controls.Add(this.RejectedLabel);
            this.Controls.Add(this.AcceptedLabel);
            this.Controls.Add(this.CalculateButton);
            this.Controls.Add(this.ResultLabel);
            this.Controls.Add(this.TestScoreTextBox);
            this.Controls.Add(this.GPATextBox);
            this.Controls.Add(this.testScore);
            this.Controls.Add(this.gpaLabel);
            this.Name = "labFour";
            this.Text = "Lab 4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label gpaLabel;
        private System.Windows.Forms.Label testScore;
        private System.Windows.Forms.TextBox GPATextBox;
        private System.Windows.Forms.TextBox TestScoreTextBox;
        private System.Windows.Forms.Label ResultLabel;
        private System.Windows.Forms.Button CalculateButton;
        private System.Windows.Forms.Label AcceptedLabel;
        private System.Windows.Forms.Label RejectedLabel;
    }
}


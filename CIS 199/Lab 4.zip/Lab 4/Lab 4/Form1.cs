﻿// Grading ID: A1010
// Lab 4
// Due Date: 10/01/2023
// CIS 199-50

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_4
{
    public partial class labFour : Form
    {
        private int acceptedCount = 0;
        private int rejectedCount = 0;
        public labFour()
        {
            InitializeComponent();
        }

        private void CalculateButton_Click(object sender, EventArgs e)
        {
            if (double.TryParse(GPATextBox.Text, out double gpa) &&
               int.TryParse(TestScoreTextBox.Text, out int testScore))

            {
                {
                    // The valid range of gpa and test score
                    if (gpa >= 0.0 && gpa <= 4.0 && testScore >= 0 && testScore <= 100)
                    {

                        // Students admission criteria meets
                        if ((gpa >= 3.0 && testScore >= 60) || (gpa < 3.0 && testScore >= 80))
                        {
                            ResultLabel.Text = "Accept";
                            acceptedCount++;
                        }
                        else
                        {
                            ResultLabel.Text = "Reject";
                            rejectedCount++;
                        }

                        // Update the running totals labels
                        AcceptedLabel.Text = $"Accepted: {acceptedCount}";
                        RejectedLabel.Text = $"Rejected: {rejectedCount}";
                    }
                    else
                    {
                        // Display an error message if input parsing fails
                        MessageBox.Show("Please enter valid GPA (0.0 - 4.0) and test score (0 - 100).", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }


                }


            }
        }
    }
}

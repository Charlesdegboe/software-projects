﻿// GRADING ID: A1010
// LAB 6
// DUE DATE: 10/29/2023
// CIS 199-50
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const int MAX_ROWS = 10;

            // Pattern A
            Console.WriteLine("Pattern A");
            for (int row = 1; row <= MAX_ROWS; row++)
            {
                for (int stars = 1; stars <= row; stars++)
                {
                    Console.Write("*"); // Print asterisks
                }
                Console.WriteLine(); // Move to the next line after each row
            }

            // Pattern B
            Console.WriteLine("\nPattern B");
            for (int row = MAX_ROWS; row >= 1; row--)
            {
                for (int stars = 1; stars <= row; stars++)
                {
                    Console.Write("*"); // Print asterisks
                }
                Console.WriteLine(); // Move to the next line after each row
            }

            // Pattern C
            Console.WriteLine("\nPattern C");
            for (int row = 1; row <= MAX_ROWS; row++)
            {
                for (int spaces = 1; spaces < row; spaces++)
                {
                    Console.Write(" "); // Print spaces
                }
                for (int stars = MAX_ROWS - row + 1; stars >= 1; stars--)
                {
                    Console.Write("*"); // Print asterisks
                }
                Console.WriteLine(); // Move to the next line after each row
            }

            // Pattern D
            Console.WriteLine("\nPattern D");
            for (int row = 1; row <= MAX_ROWS; row++)
            {
                for (int spaces = MAX_ROWS - row; spaces >= 1; spaces--)
                {
                    Console.Write(" "); // Print spaces
                }
                for (int stars = 1; stars <= row; stars++)
                {
                    Console.Write("*"); // Print asterisks
                }
                Console.WriteLine(); // Move to the next line after each row
            }
        }
        
    }
}

﻿// GRADING ID: A1010
// PROGRAM 4
// DUE DATE: 12/01/2023
// COURSE: CIS 199-50
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Product
{
    // Constants
    private const int _defaultID = 0;
    private const double _defaultPrice = 0.0;
    private const int _defaultAisle = 0;

    // Instance variables
    private string _supplierName;
    private string _productName;
    private int _productID;
    private string _productType;
    private double _productPrice;
    private int _aisleLocation;
    private bool _inStock;

    // Constructor
    public Product(string supplierName, string productName, int productID, string productType, double productPrice, int aisleLocation)
    {
        SupplierName = supplierName;
        ProductName = productName;
        ProductID = productID;
        ProductType = productType;
        ProductPrice = productPrice;
        Aisle = aisleLocation;

        OutofStock(); // Product is initially out of stock
    }

    // Properties with validation
    public string SupplierName
    {
        get { return _supplierName; }
        set { _supplierName = value; }
    }

    public string ProductName
    {
        get { return _productName; }
        set { _productName = value; }
    }

    public int ProductID
    {
        get { return _productID; }
        set { _productID = (value >= 100000 && value <= 999999) ? value : _defaultID; }
    }

    public string ProductType
    {
        get { return _productType; }
        set { _productType = value; }
    }

    public double ProductPrice
    {
        get { return _productPrice; }
        set { _productPrice = (value >= 0) ? value : _defaultPrice; }
    }

    public int Aisle
    {
        get { return _aisleLocation; }
        set { _aisleLocation = (value >= 1 && value <= 20) ? value : _defaultAisle; }
    }

    // Methods
    public void InStock()
    {
        _inStock = true;
    }

    public void OutofStock()
    {
        _inStock = false;
    }

    public bool IsOutofStock()
    {
        return !_inStock;
    }

    // Override ToString method
    public override string ToString()
    {
        return $"Supplier: {_supplierName}\nProduct: {_productName}\nID: {_productID}\nType: {_productType}\nPrice: {_productPrice:C}\nAisle: {_aisleLocation}\nIn Stock: {_inStock}\n";
    }
}


class Program
{
    static void Main()
    {
        // Create at least 5 Product objects
        Product product1 = new Product("PepsiCo", "Gatorade", 675134, "Beverage", 3.50, 4);
        Product product2 = new Product("Nestle", "Cereal1", 123456, "Cereal", 5.99, 8);
        Product product3 = new Product("Coca-Cola", "Sprite", 789012, "Beverage", 2.00, 12);
        Product product4 = new Product("Kellogg's", "Cereal2", 234567, "Cereal", 4.50, 15);
        Product product5 = new Product("General Mills", "Milk", 987654, "Dairy", 1.99, 2);

        // Store them in an array
        Product[] products = { product1, product2, product3, product4, product5 };

        // Display original data
        DisplayProducts(products);

        // Make changes to some products
        product1.InStock();
        product3.ProductPrice = 2.25;

        // Display new data
        DisplayProducts(products);

        // Call the appropriate Product method to return each product that was checked out
        Console.WriteLine($"Product 1 is {(product1.IsOutofStock() ? "out of stock" : "in stock")}");
        Console.WriteLine($"Product 3 is {(product3.IsOutofStock() ? "out of stock" : "in stock")}");

        // Display all products' data one last time
        DisplayProducts(products);
    }

    // DisplayProducts method
    public static void DisplayProducts(Product[] products)
    {
        foreach (Product product in products)
        {
            Console.WriteLine(product);
        }
        Console.WriteLine();
    }
}

﻿// Grading ID: A1010
// Lab 7
// Due Date: 11/12/2023
// Course Section: CIS 199-50
// Description: This program prompts the user to enter a positive integer representing the number of stars per side and then displays a solid square of asterisks with the specified side length.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            int numStars;

            while (true)
            {
                Console.Write("Enter the number of stars per side: ");

                if (int.TryParse(Console.ReadLine(), out numStars) && numStars > 0)
                {
                    break; // Break out of the loop if the input is a valid positive integer
                }
                else
                {
                    Console.WriteLine("Please enter a valid positive integer.");
                }
            }

            ShowSquareOfStars(numStars);
        }

        static void ShowSquareOfStars(int numStars)
        {
            for (int i = 0; i < numStars; i++)
            {
                for (int j = 0; j < numStars; j++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
        
        }
    }
}

﻿
// Exam 2
// Grading ID: A1010
// The Maui_Resort provides discounts to its customers based on the number nights booked.
// The minimum and the maximum number of nights is 1 and 7, respectively
// The more nights customers book at Maui_Resort, the better room view and discount they get. 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam2_F23
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Define the parallel arrays
            int[] numberOfNights = { 1, 2, 3, 4, 5, 6, 7 };
            string[] roomView = { "Wall", "Lobby", "Parking", "Garden", "Mountain", "Partial Ocean", "Ocean" };
            double[] pricePerNight = { 250.50, 330.33, 350.87, 375.14, 410.38, 500.45, 560.49 };
            double[] percentDiscount = { 0.15, 0.16, 0.18, 0.21, 0.23, 0.24, 0.25 };

            // Prompt the user to enter the number of nights
            Console.Write("Enter the number of nights (1-7): ");
            if (int.TryParse(Console.ReadLine(), out int enteredNights) && enteredNights >= 1 && enteredNights <= 7)
            {
                // Initialize variables for room view and total cost
                string selectedRoomView = "Not found";
                double totalCost = 0.0;

                // Search for matching number of nights
                for (int i = 0; i < numberOfNights.Length; i++)
                {
                    if (numberOfNights[i] == enteredNights)
                    {
                        selectedRoomView = roomView[i];
                        totalCost = enteredNights * pricePerNight[i] * (1 - percentDiscount[i]);
                        break; // Stop searching once a match is found
                    }
                }

                // Display the result
                Console.WriteLine($"Number of Nights: {enteredNights}");
                Console.WriteLine($"Room View: {selectedRoomView}");
                Console.WriteLine($"Total Cost: {totalCost:C2}");
            }
            else
            {
                Console.WriteLine("Invalid number of nights. Enter an integer number between 1 and 7.");
            }
        }
    }
}

﻿// Program 3
// Grading ID: A1010
// Due Date: 10/11/2023
// CIS 199-50
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program3
{
    public partial class contractCalcLbl : Form
    {
        public contractCalcLbl()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void calcBtn_Click_Click(object sender, EventArgs e)
        {
            // Declare and initialize 6 arrays
            string[] shippingProviderLookup = { "USPS", "DHL", "FedEx", "UPS" };
            double[] discountLookup = { 0.22, 0.18, 0.19, 0.20 };
            string[] businessLookup = { "John’s Books", "Office Supplies", "J.B. Car Parts", "Gevalia Coffee", "Ceylon Tea", "My Footwear" };
            double[] contractPriceLookup = { 50000, 85000, 60000, 75000, 95000, 55000 };
            int[] contractLengthLookup = { 0, 2, 5, 8 };
            double[] additionalDiscountLookup = { 0, 10000, 20000, 30000 };

            // Declare and initialize other variables
            double finalPrice;
            bool providerFound = false;

            if (shippingCombo.SelectedIndex >= 0)
            {
                if (businessCombo.SelectedIndex >= 0)
                {
                    if (int.TryParse(contractYears.Text, out int years) && years >= 0 && years <= 10)
                    {
                        double discount = 0;
                        for (int i = 0; i < shippingProviderLookup.Length && !providerFound; i++)
                        {
                            if (shippingCombo.Text == shippingProviderLookup[i])
                            {
                                discount = discountLookup[i];
                                providerFound = true;
                            }
                        }

                        double contractPrice = 0;
                        for (int i = 0; i < businessLookup.Length; i++)
                        {
                            if (businessCombo.Text == businessLookup[i])
                            {
                                contractPrice = contractPriceLookup[i];
                            }
                        }

                        double additionalDiscount = 0;
                        for (int i = 0; i < contractLengthLookup.Length; i++)
                        {
                            if (years >= contractLengthLookup[i] && years <= (i < contractLengthLookup.Length - 1 ? contractLengthLookup[i + 1] : int.MaxValue))
                            {
                                additionalDiscount = additionalDiscountLookup[i];
                                break;
                            }
                        }

                        finalPrice = contractPrice - (contractPrice * discount) - additionalDiscount;

                        // Display the results in the labels
                        shippingProviderLabel.Text = $" {shippingCombo.Text}";
                        initialContractLabel.Text = $" {contractPrice:C}";
                        companyDiscountLabel.Text = $" {contractPrice * discount:C}";
                        lengthDiscountLabel.Text = $" {additionalDiscount:C}";
                        finalContractLabel.Text = $" {finalPrice:C}";
                    }
                    else
                    {
                        MessageBox.Show("You Must Provide Valid Contract Years [0,10]");
                    }
                }
                else
                {
                    MessageBox.Show("You Must Select a Business");
                }
            }
            else
            {
                MessageBox.Show("You Must Select a Provider");
            }
        }
    }
}

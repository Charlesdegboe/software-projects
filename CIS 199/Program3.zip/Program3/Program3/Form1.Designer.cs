﻿namespace Program3
{
    partial class contractCalcLbl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.shippingLabel = new System.Windows.Forms.Label();
            this.providerLabel = new System.Windows.Forms.Label();
            this.businessLabel = new System.Windows.Forms.Label();
            this.contractLabel = new System.Windows.Forms.Label();
            this.shipproviderLabel = new System.Windows.Forms.Label();
            this.contractpriceLabel = new System.Windows.Forms.Label();
            this.discountLabel = new System.Windows.Forms.Label();
            this.LenDiscountLabel = new System.Windows.Forms.Label();
            this.FinalPriLabel = new System.Windows.Forms.Label();
            this.shippingCombo = new System.Windows.Forms.ComboBox();
            this.businessCombo = new System.Windows.Forms.ComboBox();
            this.contractYears = new System.Windows.Forms.TextBox();
            this.shippingProviderLabel = new System.Windows.Forms.TextBox();
            this.initialContractLabel = new System.Windows.Forms.TextBox();
            this.companyDiscountLabel = new System.Windows.Forms.TextBox();
            this.lengthDiscountLabel = new System.Windows.Forms.TextBox();
            this.finalContractLabel = new System.Windows.Forms.TextBox();
            this.calcBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // shippingLabel
            // 
            this.shippingLabel.AutoSize = true;
            this.shippingLabel.Location = new System.Drawing.Point(232, 84);
            this.shippingLabel.Name = "shippingLabel";
            this.shippingLabel.Size = new System.Drawing.Size(377, 32);
            this.shippingLabel.TabIndex = 0;
            this.shippingLabel.Text = "Shipping Contract Calculator";
            // 
            // providerLabel
            // 
            this.providerLabel.AutoSize = true;
            this.providerLabel.Location = new System.Drawing.Point(247, 172);
            this.providerLabel.Name = "providerLabel";
            this.providerLabel.Size = new System.Drawing.Size(128, 32);
            this.providerLabel.TabIndex = 1;
            this.providerLabel.Text = "Provider:";
            // 
            // businessLabel
            // 
            this.businessLabel.AutoSize = true;
            this.businessLabel.Location = new System.Drawing.Point(237, 257);
            this.businessLabel.Name = "businessLabel";
            this.businessLabel.Size = new System.Drawing.Size(138, 32);
            this.businessLabel.TabIndex = 2;
            this.businessLabel.Text = "Business:";
            this.businessLabel.Click += new System.EventHandler(this.label2_Click);
            // 
            // contractLabel
            // 
            this.contractLabel.AutoSize = true;
            this.contractLabel.Location = new System.Drawing.Point(151, 330);
            this.contractLabel.Name = "contractLabel";
            this.contractLabel.Size = new System.Drawing.Size(224, 32);
            this.contractLabel.TabIndex = 3;
            this.contractLabel.Text = "Contract Length:";
            // 
            // shipproviderLabel
            // 
            this.shipproviderLabel.AutoSize = true;
            this.shipproviderLabel.Location = new System.Drawing.Point(86, 549);
            this.shipproviderLabel.Name = "shipproviderLabel";
            this.shipproviderLabel.Size = new System.Drawing.Size(248, 32);
            this.shipproviderLabel.TabIndex = 4;
            this.shipproviderLabel.Text = "Shipping Provider:";
            // 
            // contractpriceLabel
            // 
            this.contractpriceLabel.AutoSize = true;
            this.contractpriceLabel.Location = new System.Drawing.Point(73, 626);
            this.contractpriceLabel.Name = "contractpriceLabel";
            this.contractpriceLabel.Size = new System.Drawing.Size(276, 32);
            this.contractpriceLabel.TabIndex = 5;
            this.contractpriceLabel.Text = "Initial Contract Price:";
            // 
            // discountLabel
            // 
            this.discountLabel.AutoSize = true;
            this.discountLabel.Location = new System.Drawing.Point(73, 692);
            this.discountLabel.Name = "discountLabel";
            this.discountLabel.Size = new System.Drawing.Size(261, 32);
            this.discountLabel.TabIndex = 6;
            this.discountLabel.Text = "Company Discount:";
            // 
            // LenDiscountLabel
            // 
            this.LenDiscountLabel.AutoSize = true;
            this.LenDiscountLabel.Location = new System.Drawing.Point(73, 778);
            this.LenDiscountLabel.Name = "LenDiscountLabel";
            this.LenDiscountLabel.Size = new System.Drawing.Size(228, 32);
            this.LenDiscountLabel.TabIndex = 7;
            this.LenDiscountLabel.Text = "Length Discount:";
            // 
            // FinalPriLabel
            // 
            this.FinalPriLabel.AutoSize = true;
            this.FinalPriLabel.Location = new System.Drawing.Point(111, 872);
            this.FinalPriLabel.Name = "FinalPriLabel";
            this.FinalPriLabel.Size = new System.Drawing.Size(157, 32);
            this.FinalPriLabel.TabIndex = 8;
            this.FinalPriLabel.Text = "Final Price:";
            // 
            // shippingCombo
            // 
            this.shippingCombo.FormattingEnabled = true;
            this.shippingCombo.Items.AddRange(new object[] {
            "USPS",
            "DHL",
            "FedEx",
            "UPS"});
            this.shippingCombo.Location = new System.Drawing.Point(422, 169);
            this.shippingCombo.Name = "shippingCombo";
            this.shippingCombo.Size = new System.Drawing.Size(237, 39);
            this.shippingCombo.TabIndex = 9;
            // 
            // businessCombo
            // 
            this.businessCombo.FormattingEnabled = true;
            this.businessCombo.Items.AddRange(new object[] {
            "John\'s Books",
            "Office Supplies",
            "J.B. Car Parts",
            "Gevalia Coffee",
            "Ceylon Tea",
            "My Footwear"});
            this.businessCombo.Location = new System.Drawing.Point(422, 257);
            this.businessCombo.Name = "businessCombo";
            this.businessCombo.Size = new System.Drawing.Size(237, 39);
            this.businessCombo.TabIndex = 10;
            // 
            // contractYears
            // 
            this.contractYears.Location = new System.Drawing.Point(422, 341);
            this.contractYears.Name = "contractYears";
            this.contractYears.Size = new System.Drawing.Size(237, 38);
            this.contractYears.TabIndex = 11;
            // 
            // shippingProviderLabel
            // 
            this.shippingProviderLabel.Location = new System.Drawing.Point(406, 546);
            this.shippingProviderLabel.Name = "shippingProviderLabel";
            this.shippingProviderLabel.Size = new System.Drawing.Size(372, 38);
            this.shippingProviderLabel.TabIndex = 12;
            // 
            // initialContractLabel
            // 
            this.initialContractLabel.Location = new System.Drawing.Point(406, 620);
            this.initialContractLabel.Name = "initialContractLabel";
            this.initialContractLabel.Size = new System.Drawing.Size(372, 38);
            this.initialContractLabel.TabIndex = 13;
            // 
            // companyDiscountLabel
            // 
            this.companyDiscountLabel.Location = new System.Drawing.Point(406, 686);
            this.companyDiscountLabel.Name = "companyDiscountLabel";
            this.companyDiscountLabel.Size = new System.Drawing.Size(372, 38);
            this.companyDiscountLabel.TabIndex = 14;
            // 
            // lengthDiscountLabel
            // 
            this.lengthDiscountLabel.Location = new System.Drawing.Point(406, 778);
            this.lengthDiscountLabel.Name = "lengthDiscountLabel";
            this.lengthDiscountLabel.Size = new System.Drawing.Size(372, 38);
            this.lengthDiscountLabel.TabIndex = 15;
            // 
            // finalContractLabel
            // 
            this.finalContractLabel.Location = new System.Drawing.Point(406, 866);
            this.finalContractLabel.Name = "finalContractLabel";
            this.finalContractLabel.Size = new System.Drawing.Size(372, 38);
            this.finalContractLabel.TabIndex = 16;
            // 
            // calcBtn
            // 
            this.calcBtn.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.calcBtn.Location = new System.Drawing.Point(372, 437);
            this.calcBtn.Name = "calcBtn";
            this.calcBtn.Size = new System.Drawing.Size(185, 47);
            this.calcBtn.TabIndex = 17;
            this.calcBtn.Text = "Calculate";
            this.calcBtn.UseVisualStyleBackColor = true;
            this.calcBtn.Click += new System.EventHandler(this.calcBtn_Click_Click);
            // 
            // contractCalcLbl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(898, 993);
            this.Controls.Add(this.calcBtn);
            this.Controls.Add(this.finalContractLabel);
            this.Controls.Add(this.lengthDiscountLabel);
            this.Controls.Add(this.companyDiscountLabel);
            this.Controls.Add(this.initialContractLabel);
            this.Controls.Add(this.shippingProviderLabel);
            this.Controls.Add(this.contractYears);
            this.Controls.Add(this.businessCombo);
            this.Controls.Add(this.shippingCombo);
            this.Controls.Add(this.FinalPriLabel);
            this.Controls.Add(this.LenDiscountLabel);
            this.Controls.Add(this.discountLabel);
            this.Controls.Add(this.contractpriceLabel);
            this.Controls.Add(this.shipproviderLabel);
            this.Controls.Add(this.contractLabel);
            this.Controls.Add(this.businessLabel);
            this.Controls.Add(this.providerLabel);
            this.Controls.Add(this.shippingLabel);
            this.Name = "contractCalcLbl";
            this.Text = "Contract Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label shippingLabel;
        private System.Windows.Forms.Label providerLabel;
        private System.Windows.Forms.Label businessLabel;
        private System.Windows.Forms.Label contractLabel;
        private System.Windows.Forms.Label shipproviderLabel;
        private System.Windows.Forms.Label contractpriceLabel;
        private System.Windows.Forms.Label discountLabel;
        private System.Windows.Forms.Label LenDiscountLabel;
        private System.Windows.Forms.Label FinalPriLabel;
        private System.Windows.Forms.ComboBox shippingCombo;
        private System.Windows.Forms.ComboBox businessCombo;
        private System.Windows.Forms.TextBox contractYears;
        private System.Windows.Forms.TextBox shippingProviderLabel;
        private System.Windows.Forms.TextBox initialContractLabel;
        private System.Windows.Forms.TextBox companyDiscountLabel;
        private System.Windows.Forms.TextBox lengthDiscountLabel;
        private System.Windows.Forms.TextBox finalContractLabel;
        private System.Windows.Forms.Button calcBtn;
    }
}


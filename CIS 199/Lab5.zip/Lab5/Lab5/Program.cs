﻿// Grading ID: A1010
// Lab5
// 10/16/2023
// CIS199-50
// The application continuously prompts the user for a series of daily high temperatures (as integers) until the user enters a sentinel value of 999
// Valid temperatures range from -20 through 130 Fahrenheit (inclusive). When the user enters a valid temperature, add it to a total; when the user enters an invalid temperature, display the error message:

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5
{
    class Program
    {
        static void Main(string[] args)
        {
            int totalTemperatures = 0; // Initialize the total temperature variable
            int validTemperatures = 0; // Initialize the count of valid temperatures
            int temperature; // Declare a variable to store the user's input temperature
            int sentinel = 999; // Define the sentinel value to exit the loop
            int minValidTemp = -20; // Define the minimum valid temperature
            int maxValidTemp = 130; // Define the maximum valid temperature

            Console.WriteLine("Enter daily high temperatures (enter 999 to exit):");

            while (true) // Create an infinite loop (until a break statement is encountered)
            {
                Console.Write("Temperature (Fahrenheit): ");
                if (int.TryParse(Console.ReadLine(), out temperature)) // Try to parse the user's input as an integer
                {
                    if (temperature == sentinel) // Check if the user entered the sentinel value
                        break; // Exit the loop if the sentinel value is entered

                    if (temperature >= minValidTemp && temperature <= maxValidTemp) // Check if the temperature is within the valid range
                    {
                        totalTemperatures += temperature; // Add the valid temperature to the total
                        validTemperatures++; // Increment the count of valid temperatures
                    }
                    else
                    {
                        Console.WriteLine("Valid temperatures range from -20 to 130. Please reenter temperature."); // Display an error message for invalid temperature
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter a valid temperature."); // Display an error message for invalid input
                }
            }

            if (validTemperatures > 0)
            {
                double averageTemperature = (double)totalTemperatures / validTemperatures; // Calculate the average temperature
                Console.WriteLine($"Number of temperatures entered: {validTemperatures}"); // Display the count of valid temperatures
                Console.WriteLine($"Average temperature: {averageTemperature:F1} Fahrenheit"); // Display the average temperature with 1 decimal place
            }
            else
            {
                Console.WriteLine("No valid temperatures entered."); // Display a message if no valid temperatures were entered
            }
        }
    }
}


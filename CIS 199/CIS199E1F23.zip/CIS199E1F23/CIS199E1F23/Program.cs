﻿// Grading ID: A1010
// Due date: 10/05/2023
// CIS 199
// This program filters the type of streaming service you can subscribe to based on the amount you spend for a month

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIS199E1F23
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the Streaming Service Recommender!");
            Console.Write("Please Enter your monthly budget: $");

            // Read the user's input as a string
            string input = Console.ReadLine();

            // Parse the input into a decimal
            if (decimal.TryParse(input, out decimal monthlyBudget))
            {
                // Determine the recommended streaming plan based on the budget
                string recommendedPlan;

                if (monthlyBudget >= 5 && monthlyBudget <= 10)
                {
                    recommendedPlan = "Basic Plan";
                }
                else if (monthlyBudget >= 11 && monthlyBudget <= 20)
                {
                    recommendedPlan = "Standard Plan";
                }
                else if (monthlyBudget >= 21 && monthlyBudget <= 30)
                {
                    recommendedPlan = "Premium Plan";
                }
                else if (monthlyBudget >= 31 && monthlyBudget <= 45)
                {
                    recommendedPlan = "Family Plan";
                }
                else if (monthlyBudget >= 46 && monthlyBudget <= 60)
                {
                    recommendedPlan = "Ultra Plan";
                }
                else if (monthlyBudget >= 61 && monthlyBudget <= 75)
                {
                    recommendedPlan = "VIP Membership";
                }
                else
                {
                    recommendedPlan = "No suitable plan available for this budget.";
                }

                Console.WriteLine($"Based on your budget of ${monthlyBudget}, we recommend the {recommendedPlan}.");
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter a valid numeric budget.");
            }
        }
    }
}

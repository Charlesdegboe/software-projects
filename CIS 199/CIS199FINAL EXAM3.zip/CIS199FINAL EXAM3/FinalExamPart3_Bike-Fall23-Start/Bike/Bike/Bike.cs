﻿// Grading ID: A1010
// CIS 199-50
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Bike
{
    public class Bike
    {
        private int _bikeID;
        private double _bikePrice;

        public string BikeName { get; set; }

        public string BikeRenter { get; set; }

        public string BikeType { get; set; }

        public int BikeID
        {
            get => _bikeID;
            set
            {
                if (value >= 1 && value <= 99999)
                {
                    _bikeID = value;
                }
                else
                {
                    _bikeID = 00000;
                }
            }
        }

        public double BikePrice
        {
            get => _bikePrice;
            set
            {
                if (value > 0)
                {
                    _bikePrice = value;
                }
                else
                {
                    _bikePrice = 0.00;
                }
            }
        }

        public Bike(string bikeName, int bikeID, double bikePrice, string bikeRenter, string bikeType)
        {
            BikeName = bikeName;
            BikeID = bikeID;
            BikePrice = bikePrice;
            BikeRenter = bikeRenter;
            BikeType = bikeType;
        }

        private bool isElectric;

        public void IsNotElectricBike()
        {
            isElectric = false;
        }

        public void IsElectricBike()
        {
            isElectric = true;
        }

        public bool IsElectric()
        {
            return isElectric;
        }

        public override string ToString()
        {
            return $@"Bike Name: {BikeName}

Bike ID: {BikeID}

Bike Price: ${BikePrice:F2}

Bike Renter: {BikeRenter}

Bike Type: {BikeType}

Electric Bike?: {IsElectric()}";
        }
    }
}
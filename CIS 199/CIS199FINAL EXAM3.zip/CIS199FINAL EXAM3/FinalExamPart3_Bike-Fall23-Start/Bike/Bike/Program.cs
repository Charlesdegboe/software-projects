﻿using static System.Console;
using System.Collections.Generic;
using System.Linq;
// Grading ID: A1010
// CIS 199-50
using System.Text;
using System.Threading.Tasks;
using System;

namespace Bike
{
    class Program
    {
        static void Main()
        {
            Bike[] bikes = new Bike[5];

            bikes[0] = new Bike("Thunderbolt", 45639, 25.00, "Alex Strong", "Road");
            bikes[1] = new Bike("Sugeno", 56390, 30.00, "Johny Cash", "Mountain");
            bikes[2] = new Bike("Mongus", 95976, 20.00, "Miley Cyrus", "Street");
            bikes[3] = new Bike("Roadrunner", 39001, 35.00, "Lady Gaga", "Terrain");
            bikes[4] = new Bike("Scorpion", 67392, 30.00, "Bradley Cooper", "Mountain");

            DisplayBikes(bikes);

            Console.ReadLine();

            bikes[0].IsNotElectricBike();
            bikes[1].IsElectricBike();

            DisplayBikes(bikes);
        }

        static void DisplayBikes(Bike[] bikes)
        {
            Console.WriteLine("Bikes we Rent:\n--------------\n");

            foreach (var bike in bikes)
            {
                Console.WriteLine(bike);
                Console.WriteLine();
            }
        }
    }
}

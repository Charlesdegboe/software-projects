﻿// Grading ID: A1010
// Porgram 1
// Due Date: 09/28/2023
// CIS 199-50

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_1
{
     class Program
    {
        // Constants for pricing and waste percentage
        const double ExtraWastePercentage = 0.10;
        const double ColorCost = 8.50;
        const double CoatCost = 10.00;
        const double LaborCostPerSquareFoot = 6.50;
        const double IlluminationCost = 75.00;
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the Mural Calculator!");
            
            // Input from the user
            Console.Write("Please Enter the Width in ft: ");
            double maxWidth = double.Parse(Console.ReadLine());

            Console.Write("Please Enter the Length in ft: ");
            double maxLength = double.Parse(Console.ReadLine());

            Console.Write("Please Enter the Number of Colors to Include: ");
            int numberOfColors = int.Parse(Console.ReadLine());

            Console.Write("Please Enter the Price of Paint: ");
            double pricePerSquareFoot = double.Parse(Console.ReadLine());

            Console.Write("How Many Coats of Paint  (1 or 2): ");
            int numberOfCoats = int.Parse(Console.ReadLine());

            Console.Write("Will the mural be illuminated? (1 for yes, 0 for no): ");
            int illumination = int.Parse(Console.ReadLine());

            // Calculate the painting area (square footage)
            double paintingArea = maxWidth * maxLength;

            // Calculate the cost of paint per square foot, including excess
            double paintCostPerSquareFoot = (paintingArea * pricePerSquareFoot) * (1 + ExtraWastePercentage) + numberOfColors * ColorCost;

            // Calculate the cost of coats of paint, including excess
            double coatCost = numberOfCoats * CoatCost;

            // Calculate the labor cost
            double laborCost = paintingArea * LaborCostPerSquareFoot;


            // Add extra cost for illumination if applicable
            if (illumination == 1)
            {
                laborCost += IlluminationCost;
            }

            // Calculate the total cost
            double totalCost = paintCostPerSquareFoot + coatCost + laborCost;

            // Display the results with currency formatting
            Console.WriteLine("\nEstimation Results:");
            Console.WriteLine($"Painting Area: {paintingArea:F1} square feet");
            Console.WriteLine($"Paint Cost: {paintCostPerSquareFoot:C}");
            Console.WriteLine($"Coating Cost: {coatCost:C}");
            Console.WriteLine($"Labor Cost: {laborCost:C}");
            Console.WriteLine($"Total Cost: {totalCost:C}");
        }
    }
}

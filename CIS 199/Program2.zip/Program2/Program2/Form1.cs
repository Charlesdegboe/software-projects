﻿//Progam2
//Due Date: 10/24/2023
//CIS199-50
// Grading ID: A1010

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program2
{
    public partial class InsuranceCalculatorForm : Form
    {
        // Constants for base rates and additional premiums
        const int MONTH = 12;
        const double MedicalBaseRate = 160.00;
        const double DentalBaseRate = 20.00;
        const double VisionBaseRate = 30.00;
        const double FullCarBaseRate = 110.00;
        const double LiabilityCarBaseRate = 50.00;
        const double SmokerPremium = 70.00;
        const double YoungDriverPremium = 25.00;
        const double LowValueCarDiscount = 0.12;
        const double AccidentSurcharge = 0.20;
        public InsuranceCalculatorForm()
        {
            InitializeComponent();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void CalcButton_Click(object sender, EventArgs e)

        {

            // Validate and parse user inputs
            if (!int.TryParse(AgeTextBox.Text, out int age) || age < 15 || age > 110)
            {
                MessageBox.Show("Enter a valid age (15-110).");
                return;
            }

            if (!int.TryParse(CarValueTextBox.Text, out int car) || car < 0)
            {
                MessageBox.Show("Enter a valid car value (>= 0).");
                return;
            }

            double totalHealthCost = 0.0;
            double totalCarCost = 0.0;

            if (InsuranceComboBox.SelectedItem != null)
            {
                string insuranceType = InsuranceComboBox.SelectedItem.ToString();

                // Health Insurance Calculations
                if (insuranceType == "Medical")
                {
                    totalHealthCost += MedicalBaseRate * MONTH;

                    if (smokeButtonYes.Checked)
                    {
                        totalHealthCost += SmokerPremium * MONTH;
                    }
                }
                else if (insuranceType == "Dental")
                {
                    totalHealthCost += DentalBaseRate * MONTH;
                }
                else if (insuranceType == "Vision")
                {
                    totalHealthCost += VisionBaseRate * MONTH;
                }

                // Car Insurance Calculations
                if (CarInsuranceComboBox.SelectedItem != null)
                {
                    string carInsuranceType = CarInsuranceComboBox.SelectedItem.ToString();

                    if (carInsuranceType == "Full")
                    {
                        totalCarCost += FullCarBaseRate * MONTH;
                    }
                    else if (carInsuranceType == "Liability")
                    {
                        totalCarCost += LiabilityCarBaseRate * MONTH;
                    }
                }

                // Apply age-related premiums
                if (age < 21)
                {
                    totalCarCost += YoungDriverPremium * MONTH;
                }

                // Apply car value discount
                if (car < 15000)
                {
                    totalCarCost -= totalCarCost * LowValueCarDiscount;
                }

                // Apply accident surcharge
                if (AccidentRadioButtonYes.Checked)
                {
                    totalCarCost += totalCarCost * AccidentSurcharge;
                }

                // Update labels to display costs in currency format
                HealthCostLabel.Text = $"{totalHealthCost:C2}";
                CarCostLabel.Text = $"{totalCarCost:C2}";
                TotalCostLabel.Text = $"{totalHealthCost + totalCarCost:C2}";



                {
                    
                    {
                       
                    }

                    
                    {
                        
                    }

                    
                }
                
                {
                }
            }
            
            {
                
            }
        }
        private void CarInsuranceComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void InsuranceCalculatorForm_Load(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}

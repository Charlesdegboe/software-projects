﻿namespace Program2
{
    partial class InsuranceCalculatorForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.calcTitle = new System.Windows.Forms.Label();
            this.ageLabel = new System.Windows.Forms.Label();
            this.carValue = new System.Windows.Forms.Label();
            this.healthCovLabel = new System.Windows.Forms.Label();
            this.carInsuranceLabel = new System.Windows.Forms.Label();
            this.smokeLabel = new System.Windows.Forms.Label();
            this.accidentLabel = new System.Windows.Forms.Label();
            this.AgeTextBox = new System.Windows.Forms.TextBox();
            this.CarValueTextBox = new System.Windows.Forms.TextBox();
            this.InsuranceComboBox = new System.Windows.Forms.ComboBox();
            this.CarInsuranceComboBox = new System.Windows.Forms.ComboBox();
            this.AccidentRadioButtonYes = new System.Windows.Forms.RadioButton();
            this.AccidentRadioButtonNo = new System.Windows.Forms.RadioButton();
            this.CalcButton = new System.Windows.Forms.Button();
            this.YearlyHealthCostLabel = new System.Windows.Forms.Label();
            this.YearlyCarCostLabel = new System.Windows.Forms.Label();
            this.ResultLabel = new System.Windows.Forms.Label();
            this.HealthCostLabel = new System.Windows.Forms.TextBox();
            this.CarCostLabel = new System.Windows.Forms.TextBox();
            this.TotalCostLabel = new System.Windows.Forms.TextBox();
            this.accidentGroupBox = new System.Windows.Forms.GroupBox();
            this.smokeGroupBox = new System.Windows.Forms.GroupBox();
            this.smokeButtonNo = new System.Windows.Forms.RadioButton();
            this.smokeButtonYes = new System.Windows.Forms.RadioButton();
            this.accidentGroupBox.SuspendLayout();
            this.smokeGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // calcTitle
            // 
            this.calcTitle.AutoSize = true;
            this.calcTitle.Location = new System.Drawing.Point(386, 9);
            this.calcTitle.Name = "calcTitle";
            this.calcTitle.Size = new System.Drawing.Size(203, 15);
            this.calcTitle.TabIndex = 0;
            this.calcTitle.Text = "Cardinal Insurance Policy Calculator";
            // 
            // ageLabel
            // 
            this.ageLabel.AutoSize = true;
            this.ageLabel.Location = new System.Drawing.Point(100, 82);
            this.ageLabel.Name = "ageLabel";
            this.ageLabel.Size = new System.Drawing.Size(91, 15);
            this.ageLabel.TabIndex = 1;
            this.ageLabel.Text = "Enter Your Age:";
            // 
            // carValue
            // 
            this.carValue.AutoSize = true;
            this.carValue.Location = new System.Drawing.Point(100, 144);
            this.carValue.Name = "carValue";
            this.carValue.Size = new System.Drawing.Size(134, 15);
            this.carValue.TabIndex = 2;
            this.carValue.Text = "Estimated Value of Car:";
            // 
            // healthCovLabel
            // 
            this.healthCovLabel.AutoSize = true;
            this.healthCovLabel.Location = new System.Drawing.Point(100, 214);
            this.healthCovLabel.Name = "healthCovLabel";
            this.healthCovLabel.Size = new System.Drawing.Size(158, 15);
            this.healthCovLabel.TabIndex = 3;
            this.healthCovLabel.Text = "Health Insurance Coverage:";
            // 
            // carInsuranceLabel
            // 
            this.carInsuranceLabel.AutoSize = true;
            this.carInsuranceLabel.Location = new System.Drawing.Point(106, 289);
            this.carInsuranceLabel.Name = "carInsuranceLabel";
            this.carInsuranceLabel.Size = new System.Drawing.Size(141, 15);
            this.carInsuranceLabel.TabIndex = 4;
            this.carInsuranceLabel.Text = "Car Insurance Coverage:";
            // 
            // smokeLabel
            // 
            this.smokeLabel.AutoSize = true;
            this.smokeLabel.Location = new System.Drawing.Point(6, 27);
            this.smokeLabel.Name = "smokeLabel";
            this.smokeLabel.Size = new System.Drawing.Size(96, 15);
            this.smokeLabel.TabIndex = 5;
            this.smokeLabel.Text = "Do You Smoke?";
            // 
            // accidentLabel
            // 
            this.accidentLabel.AutoSize = true;
            this.accidentLabel.Location = new System.Drawing.Point(18, 34);
            this.accidentLabel.Name = "accidentLabel";
            this.accidentLabel.Size = new System.Drawing.Size(170, 15);
            this.accidentLabel.TabIndex = 6;
            this.accidentLabel.Text = "Car Accident in the Past Year?";
            // 
            // AgeTextBox
            // 
            this.AgeTextBox.Location = new System.Drawing.Point(637, 82);
            this.AgeTextBox.Name = "AgeTextBox";
            this.AgeTextBox.Size = new System.Drawing.Size(268, 20);
            this.AgeTextBox.TabIndex = 7;
            // 
            // CarValueTextBox
            // 
            this.CarValueTextBox.Location = new System.Drawing.Point(637, 144);
            this.CarValueTextBox.Name = "CarValueTextBox";
            this.CarValueTextBox.Size = new System.Drawing.Size(268, 20);
            this.CarValueTextBox.TabIndex = 8;
            // 
            // InsuranceComboBox
            // 
            this.InsuranceComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.InsuranceComboBox.FormattingEnabled = true;
            this.InsuranceComboBox.Items.AddRange(new object[] {
            "Medical",
            "Dental",
            "Vision",
            "None"});
            this.InsuranceComboBox.Location = new System.Drawing.Point(639, 214);
            this.InsuranceComboBox.Name = "InsuranceComboBox";
            this.InsuranceComboBox.Size = new System.Drawing.Size(266, 39);
            this.InsuranceComboBox.TabIndex = 9;
            // 
            // CarInsuranceComboBox
            // 
            this.CarInsuranceComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CarInsuranceComboBox.FormattingEnabled = true;
            this.CarInsuranceComboBox.Items.AddRange(new object[] {
            "Full ",
            "Liability",
            "None"});
            this.CarInsuranceComboBox.Location = new System.Drawing.Point(639, 286);
            this.CarInsuranceComboBox.Name = "CarInsuranceComboBox";
            this.CarInsuranceComboBox.Size = new System.Drawing.Size(266, 39);
            this.CarInsuranceComboBox.TabIndex = 10;
            this.CarInsuranceComboBox.SelectedIndexChanged += new System.EventHandler(this.CarInsuranceComboBox_SelectedIndexChanged);
            // 
            // AccidentRadioButtonYes
            // 
            this.AccidentRadioButtonYes.AutoSize = true;
            this.AccidentRadioButtonYes.Location = new System.Drawing.Point(544, 30);
            this.AccidentRadioButtonYes.Name = "AccidentRadioButtonYes";
            this.AccidentRadioButtonYes.Size = new System.Drawing.Size(64, 32);
            this.AccidentRadioButtonYes.TabIndex = 13;
            this.AccidentRadioButtonYes.TabStop = true;
            this.AccidentRadioButtonYes.Text = "Yes";
            this.AccidentRadioButtonYes.UseVisualStyleBackColor = true;
            // 
            // AccidentRadioButtonNo
            // 
            this.AccidentRadioButtonNo.AutoSize = true;
            this.AccidentRadioButtonNo.Location = new System.Drawing.Point(544, 119);
            this.AccidentRadioButtonNo.Name = "AccidentRadioButtonNo";
            this.AccidentRadioButtonNo.Size = new System.Drawing.Size(60, 32);
            this.AccidentRadioButtonNo.TabIndex = 14;
            this.AccidentRadioButtonNo.TabStop = true;
            this.AccidentRadioButtonNo.Text = "No";
            this.AccidentRadioButtonNo.UseVisualStyleBackColor = true;
            // 
            // CalcButton
            // 
            this.CalcButton.Location = new System.Drawing.Point(249, 703);
            this.CalcButton.Name = "CalcButton";
            this.CalcButton.Size = new System.Drawing.Size(382, 68);
            this.CalcButton.TabIndex = 16;
            this.CalcButton.Text = "Calculate Policy Premiums";
            this.CalcButton.UseVisualStyleBackColor = true;
            this.CalcButton.Click += new System.EventHandler(this.CalcButton_Click);
            // 
            // YearlyHealthCostLabel
            // 
            this.YearlyHealthCostLabel.AutoSize = true;
            this.YearlyHealthCostLabel.Location = new System.Drawing.Point(70, 809);
            this.YearlyHealthCostLabel.Name = "YearlyHealthCostLabel";
            this.YearlyHealthCostLabel.Size = new System.Drawing.Size(177, 15);
            this.YearlyHealthCostLabel.TabIndex = 17;
            this.YearlyHealthCostLabel.Text = "Health Coverage Cost per Year:";
            // 
            // YearlyCarCostLabel
            // 
            this.YearlyCarCostLabel.AutoSize = true;
            this.YearlyCarCostLabel.Location = new System.Drawing.Point(76, 884);
            this.YearlyCarCostLabel.Name = "YearlyCarCostLabel";
            this.YearlyCarCostLabel.Size = new System.Drawing.Size(160, 15);
            this.YearlyCarCostLabel.TabIndex = 18;
            this.YearlyCarCostLabel.Text = "Car Coverage Cost per Year:";
            // 
            // ResultLabel
            // 
            this.ResultLabel.AutoSize = true;
            this.ResultLabel.Location = new System.Drawing.Point(76, 970);
            this.ResultLabel.Name = "ResultLabel";
            this.ResultLabel.Size = new System.Drawing.Size(148, 15);
            this.ResultLabel.TabIndex = 19;
            this.ResultLabel.Text = "Total Policy Cost per Year:";
            // 
            // HealthCostLabel
            // 
            this.HealthCostLabel.Location = new System.Drawing.Point(637, 809);
            this.HealthCostLabel.Name = "HealthCostLabel";
            this.HealthCostLabel.Size = new System.Drawing.Size(214, 20);
            this.HealthCostLabel.TabIndex = 20;
            // 
            // CarCostLabel
            // 
            this.CarCostLabel.Location = new System.Drawing.Point(637, 884);
            this.CarCostLabel.Name = "CarCostLabel";
            this.CarCostLabel.Size = new System.Drawing.Size(216, 20);
            this.CarCostLabel.TabIndex = 21;
            // 
            // TotalCostLabel
            // 
            this.TotalCostLabel.Location = new System.Drawing.Point(637, 963);
            this.TotalCostLabel.Name = "TotalCostLabel";
            this.TotalCostLabel.Size = new System.Drawing.Size(216, 20);
            this.TotalCostLabel.TabIndex = 22;
            // 
            // accidentGroupBox
            // 
            this.accidentGroupBox.Controls.Add(this.accidentLabel);
            this.accidentGroupBox.Controls.Add(this.AccidentRadioButtonYes);
            this.accidentGroupBox.Controls.Add(this.AccidentRadioButtonNo);
            this.accidentGroupBox.Location = new System.Drawing.Point(116, 508);
            this.accidentGroupBox.Name = "accidentGroupBox";
            this.accidentGroupBox.Size = new System.Drawing.Size(789, 171);
            this.accidentGroupBox.TabIndex = 28;
            this.accidentGroupBox.TabStop = false;
            // 
            // smokeGroupBox
            // 
            this.smokeGroupBox.Controls.Add(this.smokeButtonNo);
            this.smokeGroupBox.Controls.Add(this.smokeButtonYes);
            this.smokeGroupBox.Controls.Add(this.smokeLabel);
            this.smokeGroupBox.Location = new System.Drawing.Point(116, 342);
            this.smokeGroupBox.Name = "smokeGroupBox";
            this.smokeGroupBox.Size = new System.Drawing.Size(789, 170);
            this.smokeGroupBox.TabIndex = 29;
            this.smokeGroupBox.TabStop = false;
            // 
            // smokeButtonNo
            // 
            this.smokeButtonNo.AutoSize = true;
            this.smokeButtonNo.Location = new System.Drawing.Point(544, 100);
            this.smokeButtonNo.Name = "smokeButtonNo";
            this.smokeButtonNo.Size = new System.Drawing.Size(60, 32);
            this.smokeButtonNo.TabIndex = 7;
            this.smokeButtonNo.TabStop = true;
            this.smokeButtonNo.Text = "No";
            this.smokeButtonNo.UseVisualStyleBackColor = true;
            // 
            // smokeButtonYes
            // 
            this.smokeButtonYes.AutoSize = true;
            this.smokeButtonYes.Location = new System.Drawing.Point(544, 20);
            this.smokeButtonYes.Name = "smokeButtonYes";
            this.smokeButtonYes.Size = new System.Drawing.Size(64, 32);
            this.smokeButtonYes.TabIndex = 6;
            this.smokeButtonYes.TabStop = true;
            this.smokeButtonYes.Text = "Yes";
            this.smokeButtonYes.UseVisualStyleBackColor = true;
            // 
            // InsuranceCalculatorForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(931, 1058);
            this.Controls.Add(this.smokeGroupBox);
            this.Controls.Add(this.accidentGroupBox);
            this.Controls.Add(this.TotalCostLabel);
            this.Controls.Add(this.CarCostLabel);
            this.Controls.Add(this.HealthCostLabel);
            this.Controls.Add(this.ResultLabel);
            this.Controls.Add(this.YearlyCarCostLabel);
            this.Controls.Add(this.YearlyHealthCostLabel);
            this.Controls.Add(this.CalcButton);
            this.Controls.Add(this.CarInsuranceComboBox);
            this.Controls.Add(this.InsuranceComboBox);
            this.Controls.Add(this.CarValueTextBox);
            this.Controls.Add(this.AgeTextBox);
            this.Controls.Add(this.carInsuranceLabel);
            this.Controls.Add(this.healthCovLabel);
            this.Controls.Add(this.carValue);
            this.Controls.Add(this.ageLabel);
            this.Controls.Add(this.calcTitle);
            this.Name = "InsuranceCalculatorForm";
            this.Text = "Insurance Policy Calculator";
            this.Load += new System.EventHandler(this.InsuranceCalculatorForm_Load);
            this.accidentGroupBox.ResumeLayout(false);
            this.accidentGroupBox.PerformLayout();
            this.smokeGroupBox.ResumeLayout(false);
            this.smokeGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label calcTitle;
        private System.Windows.Forms.Label ageLabel;
        private System.Windows.Forms.Label carValue;
        private System.Windows.Forms.Label healthCovLabel;
        private System.Windows.Forms.Label carInsuranceLabel;
        private System.Windows.Forms.Label smokeLabel;
        private System.Windows.Forms.Label accidentLabel;
        private System.Windows.Forms.TextBox AgeTextBox;
        private System.Windows.Forms.TextBox CarValueTextBox;
        private System.Windows.Forms.ComboBox InsuranceComboBox;
        private System.Windows.Forms.ComboBox CarInsuranceComboBox;
        private System.Windows.Forms.RadioButton AccidentRadioButtonYes;
        private System.Windows.Forms.RadioButton AccidentRadioButtonNo;
        private System.Windows.Forms.Button CalcButton;
        private System.Windows.Forms.Label YearlyHealthCostLabel;
        private System.Windows.Forms.Label YearlyCarCostLabel;
        private System.Windows.Forms.Label ResultLabel;
        private System.Windows.Forms.TextBox HealthCostLabel;
        private System.Windows.Forms.TextBox CarCostLabel;
        private System.Windows.Forms.TextBox TotalCostLabel;
        private System.Windows.Forms.GroupBox accidentGroupBox;
        private System.Windows.Forms.GroupBox smokeGroupBox;
        private System.Windows.Forms.RadioButton smokeButtonNo;
        private System.Windows.Forms.RadioButton smokeButtonYes;
    }
}

